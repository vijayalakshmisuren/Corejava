package com.techno.core;

import java.util.Scanner;

public class main5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter the number");
		int numb=scn.nextInt();
		
System.out.println(Usermaincode5.countseven(numb));
	}

}
