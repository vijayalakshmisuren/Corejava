package com.techno.core;

public class Usermaincode4 {
	public static int getunique(String st) {
		char ch='0';
		int flag = 0;
		for (int i = 0; i < st.length(); i++)
		{
			if((st.charAt(0) ==ch))
			{
				flag=1;
				break;
			}
			
			for (int j = i + 1; j < st.length(); j++)
			{
				if ((st.charAt(i) == st.charAt(j)))
				{
					flag = 1;
					break;

				}

			}
			
			
		}
		if (flag == 0) {
			return 1;
		} else {
			return -1;
		}

	}

}
