package com.techno.core;

import java.security.DomainLoadStoreParameter;

public class Demo {
	public  void learning() {
		System.out.println("welcome to java programming");
	}
	public static void dog() {
		System.out.println("welcome ");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Demo ref=new Demo();
		ref.learning();
		System.out.println("welcome to technoelevate");
		
		dog();
		test.good();
		test ref1= new test();
		ref1.name();
		
	}

}
