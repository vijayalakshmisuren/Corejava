package com.techno.core;

public class Usermaincode3 {
	
public static void reversenumber(int num) {
	int sum=0;
	while (num>0) {
		sum= (sum *10) + (num%10);
    num=num/10;
	}
	
	System.out.println(sum);
	
}
}
