package com.techno.core;

import java.util.Scanner;

public class main4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter the number");
		String str=scn.next();
		int num = Usermaincode4.getunique(str);
		if (num == 1) {
			System.out.println("Unique");
		} else {
			System.out.println("Not Unique");
		}

	}

}
