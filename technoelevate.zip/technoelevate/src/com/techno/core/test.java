package com.techno.core;

public class test {
	public static void good() {
		System.out.println("welcome good");
	}
	public void name() {
		System.out.println("good one");
	}

}
