package com.techno.core;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {

		// TODO Auto-generated method stub
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter the number :");
		int number=scn.nextInt();
		int num= Usermaincode.checksum(number);
		if(num==1) {
			System.out.println("Sum of odd digits is odd");
		} else {
			System.out.println("Sum of odd digit is even");
		}
		

	}

}
