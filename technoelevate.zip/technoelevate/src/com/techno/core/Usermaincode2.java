package com.techno.core;

public class Usermaincode2 {

	public static int sumofsquareofevendigit(int num) {
		int sum=0;
		while (num>0) {
			int n1=num%10;
			if(n1%2==0) {
				sum =sum+(n1*n1);
				num=num/10;
			} else {
				num=num/10;
			}
			
		}
		return sum;
	}
}
