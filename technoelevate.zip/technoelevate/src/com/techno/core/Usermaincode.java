package com.techno.core;

public class Usermaincode {

	public static int checksum(int num) {
		int sum = 0;
		while (num > 0) { 
			int n1 = num % 10; 
			if (n1 % 2 == 0) {  
				num = num / 10;

			} else {
				sum = sum + n1;
				num = num / 10;
			}
		}

		if (sum % 2 == 0) {
			return -1;
		} else {
			return 1;
		}

	}

}
