package com.te.Assignment4;

public class Usermain7 {

	public static String Calculatedecimal(double d) {
		// TODO Auto-generated method stub
		 String str=String.valueOf(d);
		 String[] s=str.split("\\.");
		 String sm="";
		 int count=0,sum=0;
		 String si=s[0];
		 for (int i = 0; i < si.length(); i++) {
			 count++;
			
		 }
		sm=String.valueOf(count);
		sm=sm+":";
		si=s[1];
		for (int i = 0; i < si.length(); i++) {
			sum++;
			}
		sm=sm+String.valueOf(sum);;
		
		
		
		return sm;
	}

	
}
