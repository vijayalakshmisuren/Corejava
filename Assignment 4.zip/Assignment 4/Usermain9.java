package com.te.Assignment4;

public class Usermain9 {

	public static int sumelement(int[] a) {
		// TODO Auto-generated method stub
		
		int sum=0,ret=0;
		for (int i = 0; i < a.length-1; i++) {
			for (int j = i+1; j < a.length; j++) {
				
				if(a[i]==a[j]) {
					a[i]=0;
					
				}
					
				}
		}
		for (int l = 0; l < a.length; l++) {
			if(a[l]%2==0) {
				sum=sum+a[l];
				}
			
		}
		if(sum%2==0) {
			ret=sum;
			
		}else {
			ret=-1;
		}
		
		
		
		return ret;
	}

	}
