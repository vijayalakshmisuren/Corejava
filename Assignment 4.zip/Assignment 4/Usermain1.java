package com.te.Assignment4;

public class Usermain1 {

	public static int[] addsum(int[] a) {
	 int k=0;
		int b[]= new int[a.length];
		
		for (int i = 0; i < a.length; i++) {
			
			if(a[i]<10) {
				b[k]=a[i];
				k++;
				
			}
		}
		return b;
			
		}
	
}
