package com.te.Assignment4;

public class Usermain3 {

	public static boolean triblian(int[] a) {
	 boolean bval=false;
	 for (int i = 0; i < a.length-2; i++) {
		 
		 if((a[i]==a[i+1])&&(a[i+1]==a[i+2])){
			 bval=true;
			 
			 
		 }
		
	}
		
		return bval;
	}

}
