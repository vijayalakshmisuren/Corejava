package com.te.Assignment4;

import java.util.Scanner;

public class Main2 {
	public static void main(String[] args) {
		Scanner scn= new Scanner(System.in);
		System.out.println("enter the size of array");
		int n=scn.nextInt();
		int a[]= new int[n];
		for (int i = 0; i < a.length; i++) {
			a[i]=scn.nextInt();
			
		}
		System.out.println("enter one number");
		int num=scn.nextInt();
		System.out.println(Usermain2.addandreverse(a,num));
		
		
		
	}

}
