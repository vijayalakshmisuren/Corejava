package com.te.Assignment4;

import java.util.Scanner;

public class Main6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scn= new Scanner(System.in);
		System.out.println("enter the number");
		int n=scn.nextInt();
		
		boolean bh=Usermain6.perfect(n);
		if(bh) {
			System.out.println("TRUE");
		} else {
			System.out.println("FALSE");
		}

	}

}
