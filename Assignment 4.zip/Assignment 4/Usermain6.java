package com.te.Assignment4;

public class Usermain6 {

	public static boolean perfect( int num) {
		// TODO Auto-generated method stub
		boolean bval=false;
		int sum=0;
		for (int i = 1; i < num; i++) {
			if(num%i==0) {
				sum=sum+i;
			}
		}
		if(sum==num) {
			bval=true;
		}
		
		
		
		
		return bval;
	}

}
