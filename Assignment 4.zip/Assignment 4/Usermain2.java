package com.te.Assignment4;

public class Usermain2 {

	public static int addandreverse(int[] a, int num) {
		int sum=0,temp=0;
		for (int i = 0; i < a.length; i++) {
			
			if(a[i]>num) {
				sum=sum+a[i];
				}
		}
		while(sum>0) {
			temp=temp*10+(sum%10);
			sum=sum/10;
		}
		
		
		return temp;
	}

}
