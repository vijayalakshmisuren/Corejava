package com.te.Assignment4;

import java.util.Arrays;

public class Usermain4 {

	public static int calculatemedian(int[] a) {
		double mid=0, sum=0;
		Arrays.sort(a);
		if(a.length%2!=0) {
			
			mid=a.length/2;
			mid=a[(int) mid];
			
		} else {
			sum=a.length/2;
			mid=(a[(int) sum]+a[(int) (sum-1)])/2;
			
			}
		
		
		
		
		
		
		return (int) mid;
	}

}
