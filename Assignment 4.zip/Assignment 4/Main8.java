package com.te.Assignment4;

import java.util.Scanner;

public class Main8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scn=new Scanner(System.in);
		System.out.println("enter the size");
		int n=scn.nextInt();
		int a[]=new int[n];
		for (int i = 0; i < a.length; i++) {
			a[i]=scn.nextInt();
			
			
		}
		System.out.println(Usermain8.spancount(a));

	}

}
