package com.te.Assignment4;

public class Usermain8 {

	public static int spancount(int[] a) {
		// TODO Auto-generated method stub
		int sum=0;
		for (int i = 0; i < a.length; i++) {
			for (int j = i+1; j < a.length; j++) {
				if(a[i]==a[j]) {
					sum=j-i+1;
				}
				
			}
			
		}
		return sum;
	}

}
