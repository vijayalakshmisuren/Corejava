package com.te.Assignment4;

public class Usermain5 {

	public static boolean sequence(int[] a) {
		boolean bval=false;
		 for (int i = 0; i < a.length-2; i++) {
			 
			 if((a[i]==1)&&(a[i+1]==2)&&(a[i+2]==3)){
				 
				 bval=true;	 
			 }
			
		}
			
			return bval;
		}
		
}


