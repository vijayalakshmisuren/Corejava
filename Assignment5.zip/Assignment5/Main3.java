package com.assignment5.program3;

import java.util.Scanner;


public class Main3 {

	public static void main(String[] args) {
		Scanner scn=new Scanner(System.in);
		
		System.out.println("enter the string");
		String str=scn.nextLine();
		
		System.out.println("enter the number");
		int n=scn.nextInt();
		
		String sum=Usermain3.formnewword(str,n);
		
		System.out.println(sum);
		
		
	}
}
