package com.assignment5.program5;

import java.util.Scanner;

public class Main5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scn=new Scanner(System.in);
		System.out.println("enter the size string");
		int size=scn.nextInt();
		System.out.println("enter the color name");
		String[] s=new String[size];
		for (int i = 0; i < s.length; i++) {
			s[i]=scn.next();
			
		}
		System.out.println("enter the color");
		String s1=scn.next();
		int n=Usermain5.getelementposition(s,s1);
		System.out.println(n);

	}

}
