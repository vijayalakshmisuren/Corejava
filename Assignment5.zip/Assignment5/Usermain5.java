package com.assignment5.program5;

public class Usermain5 {

	public static int getelementposition(String[] s,String s1) {
		// TODO Auto-generated method stub
		String str[]=new String[s.length];
		int k=0; int sum=0;
		for (int i = 0; i < s.length; i++) {
			for (int j = i+1; j < s.length; j++) {
				if(s[i].compareTo(s[j])>0) {
					String temp=s[i];
					s[i]=s[j];
					s[j]=temp;
					
				}
				
			}
			
		}
		for (int i =s.length-1 ; i >=0; i--) {
			str[k]=s[i];
			k++;
			
			
		}
		for (int i = 0; i < str.length; i++) {
			if(str[i].equals(s1)) {
				sum=i+1;
			}
			
			
		}
		return sum;
		
		
	}

}
