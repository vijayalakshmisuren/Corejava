package com.assignment5.program3;

public class Usermain3 {

	
	public static String formnewword(String str, int n) {
		// TODO Auto-generated method stub
		String ns="";
		char[] ch=str.toCharArray();
		int n1=ch.length;
		
		for (int i = 0; i < ch.length; i++) {
			
			if(i<n) {
				
		ns=ns+ch[i];
				
			}
			else if(n>0) {
				ns=ns+ch[n1-n];
				n--;
			}
			
			
		}

	
		
		
		return ns;
	}

	
}
