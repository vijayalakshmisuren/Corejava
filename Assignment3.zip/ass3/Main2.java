package Assignment3;

import java.util.Scanner;

public class Main2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scn= new Scanner(System.in);
		System.out.println("enter the size of array");
		int n=scn.nextInt();
		int a[]=new int[n];
		for (int i = 0; i < a.length; i++) {
			a[i]=scn.nextInt();
			
			}
	
		System.out.println(Usermain2.countsum(a));
		
		

	}

}
