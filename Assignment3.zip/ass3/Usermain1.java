package Assignment3;

public class Usermain1 {

	public static int sumofpower(int[] a) {
		int sum=0;
		for (int i = 0; i < a.length; i++) {
			int pvalue=1;
			int t=i;
			while(t>0) {
				pvalue=pvalue*a[i];
				t--;
			}
			sum=sum+pvalue;
			
		}
			
		return sum;
	}
	

}
