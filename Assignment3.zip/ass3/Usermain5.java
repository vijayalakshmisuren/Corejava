package Assignment3;

public class Usermain5 {

	public static int commonnum(int[] a, int[] b) {
		int sum=0;
		 if(a.length==0) {
				sum=-1;
			} else {
		for (int i = 0; i < a.length; i++) {
			for (int j = 0; j < b.length; j++) {
				
				if(a[i]==b[j]) {
					
					sum=sum+a[i];
					
				}
			}
			
		}
			}
		
		return sum;
	}

}
