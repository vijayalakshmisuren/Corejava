package Assignment3;

import java.util.Scanner;

public class Main5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scn=new Scanner(System.in);
		System.out.println("enter the size of the Array");
		int n=scn.nextInt();
		int a[]= new int[n];
		int b[]=new int[a.length];
		
		for (int i = 0; i < n; i++) {
			
			a[i]=scn.nextInt();
		}
		for (int i = 0; i < b.length; i++) {
			b[i]=scn.nextInt();
			
		}
		System.out.println(Usermain5.commonnum(a,b));
		
	}

	}


