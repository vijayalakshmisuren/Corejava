package Assignment3;

import java.util.Scanner;

public class Main4 {

	public static void main(String[] args) {
		Scanner scn=new Scanner(System.in);
		System.out.println("enter the size of the Array");
		int n=scn.nextInt();
		int a[]= new int[n];
		
		for (int i = 0; i < n; i++) {
			
			a[i]=scn.nextInt();
		}
		System.out.println(Usermain4.averagrnum(a));
		
	}
}
