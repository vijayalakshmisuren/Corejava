package Assignment3;

public class Usermain4 {

	public static double averagrnum(int[] a) {
		int sum=0,count=0;
		for (int i = 2; i < a.length; i++) {
			for (int j = 2; j < i; j++) {
				if(i%j==0) {
					continue;
				}else {
					sum=sum+a[i];
					count++;
				}
				
			}
			
			
			
			
		}
		double num=sum/count;
		return  num;
		
	}

}
