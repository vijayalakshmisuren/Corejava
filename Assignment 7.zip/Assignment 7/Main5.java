package com.te.Assignment7;

import java.util.ArrayList;
import java.util.Scanner;

public class Main5 {

	public static void main(String[] args) {
		
		Scanner scn=new Scanner(System.in);
		System.out.println("enter the first array size");
		int n=scn.nextInt();
		System.out.println("enter the first array value");
		int n1=scn.nextInt();
		System.out.println("enter the first array values");
		ArrayList<Integer> ref= new ArrayList<Integer>();
		ArrayList<Integer> ref1= new ArrayList<Integer>();
		for (int i = 0; i < n; i++) {
			ref.add(scn.nextInt());
			
		}
		for (int i = 0; i < n1; i++) {
			ref1.add(scn.nextInt());
			
			
		}
		 System.out.println(Usermain5.arraylistsubstractor(ref,ref1));

	}

}
