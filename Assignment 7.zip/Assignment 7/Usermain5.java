package com.te.Assignment7;

import java.util.ArrayList;
import java.util.List;

public class Usermain5 {

	public static List arraylistsubstractor(ArrayList<Integer> ref, ArrayList<Integer> ref1) {
		List ref3 = new ArrayList();
		ref3.addAll(ref);
		ref.removeAll(ref1);
		ref1.removeAll(ref3);
		ref1.addAll(ref);
			
		
		
		
		return ref1;
		
		}

}
