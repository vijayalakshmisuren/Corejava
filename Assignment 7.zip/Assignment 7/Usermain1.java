package com.te.Assignment7;

import java.util.ArrayList;
import java.util.Arrays;

public class Usermain1 {

	public static ArrayList<Integer> sortmergearray(ArrayList<Integer> ref) {
	
		Object obj[]= ref.toArray();
		
		ArrayList< Integer> ref1=new ArrayList<Integer>();
		
		Arrays.sort(obj);
		for (int i = 0; i < obj.length; i++) {
			
			if(i==2||i==8||i==6) {
				
				ref1.add((Integer) obj[i]);
				
				
			}
			
		}
		return ref1;
		
	}

}
