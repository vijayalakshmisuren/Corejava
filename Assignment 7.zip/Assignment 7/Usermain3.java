package com.te.Assignment7;

import java.util.ArrayList;
import java.util.List;

public class Usermain3 {

	public static List removemultipleofthree(ArrayList<Integer> ref) {
		List list=new ArrayList();
		
		for(int j=0;j<ref.size();j++){	
			
			if((j+1)%3!=0)
			{
				list.add(ref.get(j));
			}
			
			
			}
		
		return list;
		
		
	}


}