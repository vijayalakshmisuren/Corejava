package com.te.Assignment7;

import java.util.ArrayList;
import java.util.Arrays;

public class Usermain4 {

	public static String[] arraytostring(ArrayList<String> ref) {
		
		Object obj[]=ref.toArray();
	
		String[] ref1=Arrays.asList(obj).toArray(new String[0]);
		
		Arrays.sort(ref1);
		
		
		
		return ref1;
	}

}
