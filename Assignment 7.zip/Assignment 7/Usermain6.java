package com.te.Assignment7;

import java.util.ArrayList;

public class Usermain6 {

	public static ArrayList<Integer> arraymanuplation(ArrayList<Integer> ref, ArrayList<Integer> ref1) {
		ArrayList<Integer> ref3= new ArrayList<Integer>();
		for (int i = 0; i < ref.size(); i++) {
			if(i%2==0) {
				ref3.add(ref.get(i));
			}else {
				ref3.add(ref1.get(i));
			}
			
		}

		return ref3;
	}

}
