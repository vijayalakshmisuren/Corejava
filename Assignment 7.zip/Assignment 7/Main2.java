package com.te.Assignment7;

import java.util.ArrayList;
import java.util.Scanner;

public class Main2 {

	public static void main(String[] args) {
		
		Scanner scn=new Scanner(System.in);
		System.out.println("enter the  array size");
		int n=scn.nextInt();
		
		ArrayList<String> ref=new ArrayList<String>();
		
		for (int i = 0; i < n; i++) {
			String s=scn.next();
			
			ref.add(s);
			
		}
System.out.println(Usermain2.matchcharacter(ref));
	}

}
