package com.te.Assignment7;

import java.util.ArrayList;
import java.util.Scanner;

public class Main4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner scn=new Scanner(System.in);
System.out.println("enter the value");
int num=scn.nextInt();
ArrayList< String> ref=new ArrayList<String>();
for (int i = 0; i < num; i++) {
	 String st=scn.next();
	ref.add(st);
	
}
 String[] st=(Usermain4.arraytostring(ref));
 
 for (int i = 0; i < st.length; i++) {
	 System.out.println(st[i]);
	
}
	}

}
