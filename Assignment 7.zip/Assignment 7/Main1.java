package com.te.Assignment7;

import java.util.ArrayList;
import java.util.Scanner;

public class Main1 {

	public static void main(String[] args) {
		Scanner scn=new Scanner(System.in);
		System.out.println("enter the  array size");
		int n=scn.nextInt();
		ArrayList<Integer> ref=new ArrayList<Integer>();
		for (int i = 0; i < n; i++) {
			
			ref.add(scn.nextInt());
			
		}
ArrayList< Integer> ref1=new ArrayList<Integer>();
for (int i = 0; i < n; i++) {
	
	ref1.add(scn.nextInt());
	
	
}
     ref.addAll(ref1);
		System.out.println(Usermain1.sortmergearray(ref));
		
	}

}
