package com.te.Assignment7;

import java.util.ArrayList;
import java.util.Scanner;

public class Main3 {

	public static void main(String[] args) {
		Scanner scn=new Scanner(System.in);
		System.out.println("enter the size");
		int num=scn.nextInt();
		
		ArrayList< Integer> ref= new ArrayList<Integer>();
		
		for (int i = 0; i < num; i++) {
			
             int s=scn.nextInt();
			
			ref.add(s);
			
		}
		System.out.println(Usermain3.removemultipleofthree(ref));
	}

	}


