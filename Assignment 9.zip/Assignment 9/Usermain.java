package com.te.Assignment8;

import java.util.Iterator;
import java.util.Map;

public class Usermain {

	public static String getmaxkeyvalue(Map<Integer, String> ref) {
		int temp=0;
		Iterator<Integer> itr=ref.keySet().iterator();
		while (itr.hasNext()) {
			int key=itr.next();
			if(key>temp) {
				temp=key;
			}
			
			
		}
		String s= ref.get(temp);;
		return s;
	}

}
