package com.te.Assignment8;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Main3 {

	public static void main(String[] args) {
		Scanner scn=new Scanner(System.in);
		Map<Integer, Integer> ref= new HashMap<Integer, Integer>();
		System.out.println("enter the size of map");
		int size=scn.nextInt();
		System.out.println("enter the key and value of hashmap");
		for (int i = 0; i < size; i++) {
			ref.put(scn.nextInt(), scn.nextInt());
		}
		
		System.out.println(Usermain3.getyear(ref));
	}


	}


