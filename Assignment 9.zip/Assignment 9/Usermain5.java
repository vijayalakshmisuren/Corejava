package com.te.Assignment8;

import java.util.HashMap;

public class Usermain5 {

	public static HashMap<String, String> getstateId(String[] str) {
		HashMap<String, String> map=new HashMap<String, String>();
		for (int i = 0; i < str.length; i++) {
			String name="";
			String sta= str[i];
			for (int j = 0; j < sta.length(); j++) {
				
			if(j<3) {
					name=name+sta.charAt(j);
			}
			for (int k = 0; k < str.length; k++) {
				map.put(str[i], name.toUpperCase());
				
			}
				
			}
			
			
		}
		
		
		
		
		return map;
	}



}
