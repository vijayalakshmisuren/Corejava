package com.te.Assignment8;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class Usermain4 {

	public static ArrayList<String> obtiondesignation(Map<String, String> ref, String str) {
		ArrayList<String> good=new ArrayList<String>();
		
		Iterator<String> itr=ref.keySet().iterator();
		while (itr.hasNext()) {
			String key= itr.next();
			String val=ref.get(key);
			if(val.equals(str)) {
				good.add(key);
			}
			
		}
	
		return good;
	}

	
}
