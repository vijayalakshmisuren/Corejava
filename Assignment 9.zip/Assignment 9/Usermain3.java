package com.te.Assignment8;

import java.util.Iterator;
import java.util.Map;

public class Usermain3 {
static int temp=0, sum=0;
	public static int getyear(Map<Integer, Integer> ref) {
		
		Iterator<Integer> itr=ref.keySet().iterator();
		while (itr.hasNext()) {
			int key= itr.next();
			int val=ref.get(key);
			if(val>temp) {
				temp=val;
				sum=key;
				
			}
			
		}
		
		
		
		
		
		
		return sum ;
	}

}
