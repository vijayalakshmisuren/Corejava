package com.te.Assignment8;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

public class Main {

	public static void main(String[] args) {
		Scanner scn=new Scanner(System.in);
		Map<Integer, String> ref= new HashMap<Integer, String>();
		System.out.println("enter the size of map");
		int size=scn.nextInt();
		System.out.println("enter the key and value of hashmap");
		for (int i = 0; i < size; i++) {
			ref.put(scn.nextInt(), scn.next());
		}
		
		System.out.println(Usermain.getmaxkeyvalue(ref));
	}

}
