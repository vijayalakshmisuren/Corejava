package com.te.Assignment8;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Main4 {

	public static void main(String[] args) {
		
		Scanner scn=new Scanner(System.in);
		Map<String, String> ref= new HashMap<String, String>();
		System.out.println("enter the size of map");
		int size=scn.nextInt();
		System.out.println("enter the key and value of hashmap");
		for (int i = 0; i < size; i++) {
			ref.put(scn.next(), scn.next());
		}
		System.out.println("enter the designation");
		String str=scn.next();
		
		System.out.println(Usermain4.obtiondesignation(ref,str));
	}
	}


