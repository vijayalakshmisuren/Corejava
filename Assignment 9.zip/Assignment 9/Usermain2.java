package com.te.Assignment8;

import java.util.Iterator;
import java.util.Map;

public class Usermain2 {

	public static String getcapital(Map<String, String> ref, String str) {
		String st="";
		Iterator<String> itr=ref.keySet().iterator();
		while (itr.hasNext()) {
			String s= itr.next();
			String s1=ref.get(s);
			if(s.equals(str)) {
				st=s1+"$"+s;
				
			}
			
		}
		
		
	
		return st;
	}

}
