package com.te.Assignment8;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;

public class Main5 {

	public static void main(String[] args) {
		Scanner scn=new Scanner(System.in);
	
		System.out.println("enter the size of the array");
		int size=scn.nextInt();
		String[] str=new String[size]; 
		System.out.println("enter the state names");
		for (int i = 0; i < str.length; i++) {
			str[i]=scn.next();
			
		}
		Map<String, String> ref1= (Usermain5.getstateId(str));
		Iterator<String> itr=ref1.keySet().iterator();
		while (itr.hasNext()) {
			String key= itr.next();
		System.out.print(ref1.get(key)+":");
		System.out.print(key);
		System.out.println();
		}
		
	}

}
